itemStr="TDR_Seafood,TDR_Porkbone,TDR_Spicyporkbone,Lays_Original"
itemStr=itemStr.replace(" ", "")
itemList=itemStr.split(',')
print(itemList)